package org.thunlp.tool;

import java.io.IOException;

public interface GenericTool {
	public void run( String [] args) throws Exception;
}
