package org.thunlp.tagsuggest.common;

import sun.rmi.runtime.Log;

import java.io.File;
import java.io.IOException;
import java.util.logging.Logger;

public class GizaPP {
    private String giza_path = null;
    private Logger LOG;

    public GizaPP(String giza_path, Logger LOG){
        this.giza_path = giza_path;
        this.LOG = LOG;
    }


    private void gizapp(File modelDir) throws IOException, InterruptedException {
        Runtime rn = Runtime.getRuntime();
        Process p = null;
        p = rn
                .exec(giza_path + File.separator + "mkcls -c80 -pbook -Vbook.vcb.classes opt",
                        null, modelDir);
        p.waitFor();
        p = rn
                .exec(giza_path + File.separator + "mkcls -c80 -pbookTag -VbookTag.vcb.classes opt",
                        null, modelDir);
        p.waitFor();
        LOG.info("mkcls ok!");
        p = rn
                .exec(giza_path + File.separator + "plain2snt.out bookTag book",
                        null, modelDir);
        p.waitFor();
        LOG.info("plain2snt ok!");

        // from word to tag
        p = rn.exec(giza_path + File.separator + "GIZA++ -S book.vcb -T bookTag.vcb -C book_bookTag.snt  -m1 5 -m2 0 -mh 0 -m3 0 -m4 0 -model1dumpfrequency 1"
                , null, modelDir);
        StreamGobbler errorGobbler = new StreamGobbler(p.getErrorStream(),
                "Error", LOG);
        StreamGobbler outputGobbler = new StreamGobbler(p.getInputStream(),
                "Output", LOG);
        errorGobbler.start();
        outputGobbler.start();
        p.waitFor();
        LOG.info("GIZA++ word to tag Ok!");

        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }

        // from tag to word
        p = rn.exec(giza_path + File.separator + "GIZA++ -S bookTag.vcb -T book.vcb -C bookTag_book.snt -m1 5 -m2 0 -mh 0 -m3 0 -m4 0  -model1dumpfrequency 1",
                null, modelDir);
        errorGobbler = new StreamGobbler(p.getErrorStream(), "Error", LOG);
        outputGobbler = new StreamGobbler(p.getInputStream(), "Output", LOG);
        errorGobbler.start();
        outputGobbler.start();
        p.waitFor();
        LOG.info("GIZA++ tag to word Ok!");
    }





}
