package org.thunlp.tagsuggest.common;

import java.util.List;

public interface GenerativeTagSuggest extends TagSuggest {
  public void likelihood(Post p, List<Double> likelihoods);
}
