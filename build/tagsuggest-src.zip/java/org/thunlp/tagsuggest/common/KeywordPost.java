package org.thunlp.tagsuggest.common;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * A post with tags.
 * 
 * @author cxx
 * 
 */
public class KeywordPost extends Post{
	//private String id = "";
	private String summary = "";
	// private Set<String> keys;
	private String date = "";
	private String source = "";

	public KeywordPost() {
		super();
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getSummary() {
		return summary;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getDate() {
		return date;
	}
	
	public void setSource(String source) {
		this.source = source;
	}

	public String getSource() {
		return source;
	}
	
}
