package org.thunlp.tagsuggest.common;

public interface FeatureExtractor {
  String [] extract(Post p);
}
