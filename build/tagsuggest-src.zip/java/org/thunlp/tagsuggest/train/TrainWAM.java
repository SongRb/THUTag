package org.thunlp.tagsuggest.train;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.*;
import java.util.Map.Entry;
import java.util.logging.Logger;

import org.thunlp.io.JsonUtil;
import org.thunlp.io.RecordReader;
import org.thunlp.language.chinese.ForwardMaxWordSegment;
import org.thunlp.language.chinese.WordSegment;
import org.thunlp.misc.Counter;
import org.thunlp.misc.Flags;
import org.thunlp.tagsuggest.common.*;
import org.thunlp.text.Lexicon;
import org.thunlp.tool.GenericTool;

public class TrainWAM extends TrainWAMBase {
//    private static Logger LOG = Logger.getAnonymousLogger();
//    private Properties config = null;
//    private String fold = "";
//    private String giza_path = null;
//
//    JsonUtil J = new JsonUtil();
//    WordFeatureExtractor extrator = null;
//    TagFilter tagFilter = null;
//    WordSegment ws = null;

//    @Override
//    public void run(String[] args) throws Exception {
//        // TODO Auto-generated method stub
//        Flags flags = new Flags();
//        flags.add("input");
//        flags.add("output");
//        flags.add("config");
//        flags.parseAndCheck(args);
//
//        Properties config = ConfigIO
//                .configFromString(flags.getString("config"));
//        train(flags.getString("input"), flags.getString("output"), config);
//    }

//    @Override
//    public void train(String inputPath, String modelPath, Properties config)
//            throws IOException {
//        // TODO Auto-generated method stub
//        this.config = config;
//        this.fold = config.getProperty("fold", "");
//
//        giza_path = config.getProperty("giza_path", RtuMain.getProjectPath());
//        LOG.info("giza_path:" + giza_path);
//
//        buildProTable(inputPath, new File(modelPath));
//    }

    public void buildProTable(String input, File modelDir) {

        try {
            if (!modelDir.exists()) {
                modelDir.mkdir();
            }

            createExtractor(input);
            
            // the first time : create wordlex and taglex to store the tf and df
            // information
            Lexicon localWordLex = new Lexicon();
            Lexicon localTagLex = new Lexicon();

            createLocalLex(localWordLex, localTagLex, modelDir, input);

            double scoreLimit = Double.parseDouble(config.getProperty("scoreLimit", "0.1"));

            // the second time :
            createTrainData(input, modelDir, localWordLex, scoreLimit);

            // training
            gizappTrain(modelDir);


        } catch (Exception e) {
            LOG.info("Error exec!");
        }
    }

//    private void createExtractor(String input) throws IOException {
//        ws = new ForwardMaxWordSegment();
//        Lexicon wordLex = new Lexicon();
//        Lexicon tagLex = new Lexicon();
//        WordFeatureExtractor.buildLexicons(input, wordLex, tagLex, config);
//        extrator = new WordFeatureExtractor(config);
//        extrator.setWordLexicon(wordLex);
//        extrator.setTagLexicon(tagLex);
//        tagFilter = new TagFilter(config, tagLex);
//    }
//
//    private void createTrainData(String input, File modelDir, Lexicon localWordLex, double scoreLimit) throws IOException {
//        BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
//                new FileOutputStream(modelDir.getAbsolutePath() + "/book"),
//                "UTF-8"));
//
//        BufferedWriter outTag = new BufferedWriter(new OutputStreamWriter(
//                new FileOutputStream(modelDir.getAbsolutePath()
//                        + "/bookTag"), "UTF-8"));
//        RecordReader reader = new RecordReader(input);
//        while (reader.next()) {
//            KeywordPost p = J.fromJson(reader.value(), KeywordPost.class);
//            if (fold.length() > 0 && p.getExtras().equals(fold)) {
//                continue;
//            }
//            String title = p.getTitle();
//            String[] titleWords = ws.segment(title);
//
//            writeResultLines(titleWords, localWordLex, out);
//            writeResultLines(titleWords, localWordLex, outTag);
//
//            Vector<Double> wordTfidf = new Vector<>();
//            Vector<String> wordList = new Vector<>();
//            double normalize = 0.0;
//            Counter<String> termFreq = new Counter<>();
//            for (String word : titleWords) {
//                termFreq.inc(word, 1);
//            }
//            for (Entry<String, Long> e : termFreq) {
//                String word = e.getKey();
//                if (localWordLex.getWord(word) == null) {
//                    continue;
//                }
//                wordList.add(word);
//
//                double tf = ((double) e.getValue())
//                        / ((double) titleWords.length);
//                double idf = Math.log(((double) localWordLex.getNumDocs())
//                        / ((double) localWordLex.getWord(word)
//                        .getDocumentFrequency()));
//                double tfidf = tf * idf;
//                wordTfidf.add(tfidf);
//                normalize += tfidf * tfidf;
//            }
//            Vector<Double> wordProb = new Vector<>();
//            for (int i = 0; i < wordTfidf.size(); i++) {
//                wordProb.add(wordTfidf.elementAt(i) / normalize);
//            }
//
//            String content = p.getSummary() + p.getContent();
//            content = content.replaceAll("\n", "");
//            String[] splittedSentences = content.split("[。！]");
//
//            for (String sentence : splittedSentences) {
//
//
//                if (splittedSentences.length <= 2) {
//                    continue;
//                }
//                double score = 0.0;
//                String[] words = ws.segment(sentence);
//                HashMap<String, Integer> contentTf = new HashMap<>();
//                for (String word : words) {
//                    if (contentTf.containsKey(word)) {
//                        int tmp = contentTf.get(word) + 1;
//                        contentTf.put(word, tmp + 1);
//                    } else {
//                        contentTf.put(word, 1);
//                    }
//
//                }
//
//                HashMap<String, Double> contentTfidf = new HashMap<>();
//                normalize = 0.0;
//                for (Entry<String, Integer> e : contentTf.entrySet()) {
//                    String word = e.getKey();
//                    if (localWordLex.getWord(word) == null) {
//                        continue;
//                    }
//                    double tf = ((double) e.getValue()) / ((double) words.length);
//                    double idf = Math.log(((double) localWordLex.getNumDocs())
//                            / ((double) localWordLex.getWord(word)
//                            .getDocumentFrequency()));
//                    double tfidf = tf * idf;
//                    contentTfidf.put(word, tfidf);
//                    normalize += tfidf * tfidf;
//                }
//                for (Entry<String, Double> e : contentTfidf.entrySet()) {
//                    e.setValue(e.getValue() / normalize);
//                }
//                for (int j = 0; j < wordList.size(); j++) {
//                    String word = wordList.get(j);
//                    if (contentTfidf.containsKey(word)) {
//                        score += contentTfidf.get(word) * wordProb.get(j);
//                    }
//                }
//                if (score >= scoreLimit) {
//                    writeResultLines(words, localWordLex, out);
//                    writeResultLines(titleWords, localWordLex, outTag);
//
//                }
//            }
//
//        }
//
//        reader.close();
//        out.close();
//        outTag.close();
//        LOG.info("source and target are prepared!");
//    }
//
//    private void createLocalLex(Lexicon localWordLex, Lexicon localTagLex, File modelDir, String input) throws IOException {
//        File wordLexFile = new File(modelDir.getAbsolutePath() + "/wordlex");
//        File tagLexFile = new File(modelDir.getAbsolutePath() + "/taglex");
//
//        RecordReader reader = new RecordReader(input);
//
//        if (wordLexFile.exists() && tagLexFile.exists()) {
//            LOG.info("Use cached lexicons");
//            localWordLex.loadFromFile(wordLexFile);
//            localTagLex.loadFromFile(tagLexFile);
//        } else {
//            while (reader.next()) {
//                KeywordPost p = J.fromJson(reader.value(), KeywordPost.class);
//                if (fold.length() > 0 && p.getExtras().equals(fold)) {
//                    continue;
//                }
//                String[] features = extrator.extractKeyword(p, true, true, true);
//                if (features.length <= 0) {
//                    continue;
//                }
//
//
//                Set<String> filtered = new HashSet<>();
//                tagFilter.filterWithNorm(p.getTags(), filtered);
//                if (filtered == null) {
//                    continue;
//                }
//                localWordLex.addDocument(features);
//                localTagLex.addDocument(filtered
//                        .toArray(new String[filtered.size()]));
//
//                if (reader.numRead() % 1000 == 0)
//                    LOG.info(modelDir.getAbsolutePath()
//                            + " building lexicons: " + reader.numRead());
//            }
//            reader.close();
//            localWordLex.saveToFile(wordLexFile);
//            localTagLex.saveToFile(tagLexFile);
//        }
//
//
//    }
//
//    private void gizappTrain(File modelDir) throws IOException, InterruptedException {
//        Runtime rn = Runtime.getRuntime();
//        Process p = null;
//        p = rn
//                .exec(giza_path + File.separator + "mkcls -c80 -pbook -Vbook.vcb.classes opt",
//                        null, modelDir);
//        p.waitFor();
//        p = rn
//                .exec(giza_path + File.separator + "mkcls -c80 -pbookTag -VbookTag.vcb.classes opt",
//                        null, modelDir);
//        p.waitFor();
//        LOG.info("mkcls ok!");
//        p = rn
//                .exec(giza_path + File.separator + "plain2snt.out bookTag book",
//                        null, modelDir);
//        p.waitFor();
//        LOG.info("plain2snt ok!");
//
//        // from word to tag
//        p = rn.exec(giza_path + File.separator + "GIZA++ -S book.vcb -T bookTag.vcb -C book_bookTag.snt  -m1 5 -m2 0 -mh 0 -m3 0 -m4 0 -model1dumpfrequency 1"
//                , null, modelDir);
//        org.thunlp.tagsuggest.common.StreamGobbler errorGobbler = new org.thunlp.tagsuggest.common.StreamGobbler(p.getErrorStream(),
//                "Error", LOG);
//        org.thunlp.tagsuggest.common.StreamGobbler outputGobbler = new org.thunlp.tagsuggest.common.StreamGobbler(p.getInputStream(),
//                "Output", LOG);
//        errorGobbler.start();
//        outputGobbler.start();
//        p.waitFor();
//        LOG.info("GIZA++ word to tag Ok!");
//
//        try {
//            Thread.sleep(1000);
//        } catch (InterruptedException ex) {
//            Thread.currentThread().interrupt();
//        }
//
//        // from tag to word
//        p = rn.exec(giza_path + File.separator + "GIZA++ -S bookTag.vcb -T book.vcb -C bookTag_book.snt -m1 5 -m2 0 -mh 0 -m3 0 -m4 0  -model1dumpfrequency 1",
//                null, modelDir);
//        errorGobbler = new org.thunlp.tagsuggest.common.StreamGobbler(p.getErrorStream(), "Error", LOG);
//        outputGobbler = new org.thunlp.tagsuggest.common.StreamGobbler(p.getInputStream(), "Output", LOG);
//        errorGobbler.start();
//        outputGobbler.start();
//        p.waitFor();
//        LOG.info("GIZA++ tag to word Ok!");
//    }
//
//    private void writeResultLine(String[] wordList, Lexicon lex, BufferedWriter bufferedWriter) throws IOException {
//        for (int j = 0; j < wordList.length; j++) {
//            if (lex.getWord(wordList[j]) != null) {
//                if (j == 0) {
//                    bufferedWriter.write(wordList[j]);
//                } else {
//                    bufferedWriter.write(" " + wordList[j]);
//                }
//            }
//        }
//    }
//
//    private void writeResultLines(String[] wordList, Lexicon lex, BufferedWriter bufferedWriter) throws IOException {
//        writeResultLine(wordList, lex, bufferedWriter);
//        bufferedWriter.newLine();
//        bufferedWriter.flush();
//    }


    public static void main(String[] args) throws IOException {
        TrainWAM Test = new TrainWAM();
        Test.config = ConfigIO.configFromString("num_tags=10;norm=all_log;isSample=true;model=/home/meepo/test/sample/book.model;size=70000;minwordfreq=10;mintagfreq=10;selfTrans=0.2;commonLimit=2");
        Test.buildProTable("/home/meepo/test/sample/post.dat", new
                File("/home/meepo/test/sample"));
    }

}