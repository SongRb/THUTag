package org.thunlp.tagsuggest.dataset;

@SuppressWarnings("serial")
public class ParseException extends RuntimeException {
	public ParseException(String msg) {
		super(msg);
	}
	
	public ParseException(String msg, Exception cause) {
		super(msg, cause);
	}
}