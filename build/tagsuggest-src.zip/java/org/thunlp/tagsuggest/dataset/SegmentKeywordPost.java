/**
 * Created：Jun 3, 2013 11:33:21 AM  
 * Project：cxx  
 * @author cxx
 * @since JDK 1.6.0_13  
 * filename：SegmentKeywordPost.java  
 * description：  
 */
package org.thunlp.tagsuggest.dataset;

import org.thunlp.io.JsonUtil;

public class SegmentKeywordPost {
	
	private JsonUtil J = new JsonUtil();
	
	
	
	/**
	 * <p>Title:main</p>
	 * <p>Description:<p>
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
